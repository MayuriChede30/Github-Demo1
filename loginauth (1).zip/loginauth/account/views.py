from django.contrib import auth
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.shortcuts import render, redirect

# Create your views here.
from django.views.decorators.csrf import csrf_exempt


def ahome(request):
    return render(request,'account/ahome.html')
def signup(request):
    if request.method == "POST":
        if request.POST['password']==request.POST['password2']:
            try:
                user=User.objects.get(username=request.POST['username'])
                return render(request,'account/signup.html',{'error':'username is already taken'})
            except User.DoesNotExist:
                user=User.objects.create_user(request.POST['username'],password=request.POST['password'])
                auth.login(request,user)
                return redirect('ahome')
        else:
            return render(request,'account/signup.html',{'error':'password doesnt matched'})
    else:
        return render(request,'account/signup.html')
def login(request):
    if request.method=='POST':
        uname=request.POST['username']
        password=request.POST['password']
        user= authenticate(username=uname,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect('ahome')
        else:
            return render(request, 'account/login.html',{'error':'username or password is incorrect'})
    else:
        return render(request,'account/login.html',{'error':'username or password is incorrect'})

@csrf_exempt
def logout(request):
    auth.logout(request)
    return redirect('ahome')