from django.shortcuts import render

# Create your views here.
def phome(request):
    return render(request,'product/phome.html')
def create(request):
    return render(request,'product/create.html')
