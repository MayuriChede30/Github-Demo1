from django.urls import path, include

from product import views

urlpatterns=[
    path('create/',views.create,name='create')
]